from _struct import *
from _struct import _clearcache
